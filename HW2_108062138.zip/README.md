# Q1
- 按下`clear all output`
- 接著按下`run all`
# Q2
- 按下`clear all output`
- 接著按下`run all`